"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RecipeModel = void 0;
const mongoose_1 = require("mongoose");
const ingredient_1 = require("./ingredient");
const RecipeSchema = new mongoose_1.Schema({
    name: {
        type: String,
        required: true,
        unique: true,
    },
    instructions: {
        type: String,
        required: true,
    },
    ingredients: [ingredient_1.IngredientSchema],
});
exports.RecipeModel = (0, mongoose_1.model)("Recipe", RecipeSchema);
//# sourceMappingURL=recipe.js.map