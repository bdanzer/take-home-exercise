"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.recipeMiddleware = void 0;
const models_1 = require("../models");
const recipeMiddleware = async (req, res, next) => {
    const recipeId = req.params.id;
    if (!recipeId)
        res.status(404).send();
    const foundRecipes = await models_1.RecipeModel.findById(recipeId);
    if (foundRecipes) {
        res.status(200).send(foundRecipes);
    }
    else {
        res.status(404).send();
    }
};
exports.recipeMiddleware = recipeMiddleware;
//# sourceMappingURL=recipe.js.map