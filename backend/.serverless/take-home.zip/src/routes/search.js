"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.searchMiddleware = void 0;
const models_1 = require("../models");
const allIngredients = ["flour", "sugar", "salt", "butter", "milk"];
const escapeRegex = (text) => {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};
const recipeCleaner = (recipe) => {
    const { id, name, ingredients, instructions } = recipe;
    return { id, name, ingredients, instructions };
};
const searchMiddleware = async (req, res) => {
    const { name, ingredients } = req.body;
    const query = {};
    if (name) {
        query.name = new RegExp(escapeRegex(name), "gi");
    }
    if (ingredients) {
        const whatsLeft = allIngredients.filter((ing) => !ingredients.includes(ing));
        query["ingredients.name"] = { $nin: whatsLeft };
    }
    const foundRecipes = await models_1.RecipeModel.find(query);
    const builtRecipes = foundRecipes.map(recipeCleaner);
    res.send(builtRecipes);
};
exports.searchMiddleware = searchMiddleware;
//# sourceMappingURL=search.js.map