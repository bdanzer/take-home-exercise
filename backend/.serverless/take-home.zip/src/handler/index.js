"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverlessExpressHandler = void 0;
require("source-map-support/register");
const db_1 = require("../db");
const serverless_express_1 = __importDefault(require("@vendia/serverless-express"));
const __1 = require("..");
let serverlessExpressInstance;
async function setup(event, context) {
    await (0, db_1.connectDb)();
    serverlessExpressInstance = (0, serverless_express_1.default)({ app: __1.app });
    return serverlessExpressInstance(event, context);
}
function serverlessExpressHandler(event, context) {
    console.log("this is called");
    //   if (serverlessExpressInstance)
    //     return serverlessExpressInstance(event, context)
    return setup(event, context);
}
exports.serverlessExpressHandler = serverlessExpressHandler;
//# sourceMappingURL=index.js.map