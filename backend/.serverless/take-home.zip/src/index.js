"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
require("dotenv/config");
const express_1 = __importDefault(require("express"));
// import express from "serverless-express/express"
const body_parser_1 = __importDefault(require("body-parser"));
const routes_1 = require("./routes");
const cors_1 = __importDefault(require("cors"));
exports.app = (0, express_1.default)();
// add parsers for the body
exports.app.use((0, cors_1.default)({
    origin: [
        "http://localhost:3000",
        "https://feature-search.d3trv6vvetvuxy.amplifyapp.com",
    ],
}));
exports.app.use(body_parser_1.default.json());
exports.app.use(body_parser_1.default.urlencoded({ extended: false }));
exports.app.use(async (res, req, next) => {
    await new Promise((resolve) => setTimeout(() => resolve(0), 1000)); //adding a set timeout to show loading states on the UI better for now
    next();
});
// create our routes
exports.app.get("/api/recipe/:id", routes_1.recipeMiddleware);
exports.app.post("/api/search", routes_1.searchMiddleware);
// Handle in-valid route
exports.app.all("*", function (req, res) {
    const response = { data: null, message: "Route not found!!" };
    res.status(400).send(response);
});
//# sourceMappingURL=index.js.map