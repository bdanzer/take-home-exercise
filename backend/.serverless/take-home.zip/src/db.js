"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDb = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const connectDb = async () => {
    const url = `mongodb+srv://bdanzer:${process.env.DATABASE_PASS}@cluster1.zxqj5.mongodb.net`;
    const connection = await mongoose_1.default.connect(url, {
        useNewUrlParser: true,
        keepAlive: true,
        connectTimeoutMS: 30000,
    });
    return connection;
};
exports.connectDb = connectDb;
//# sourceMappingURL=db.js.map